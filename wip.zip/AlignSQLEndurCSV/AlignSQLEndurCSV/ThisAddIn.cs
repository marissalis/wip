﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;


//Sub CallVSTOMethod()
//    Dim addIn As COMAddIn
//    Dim automationObject As Object
//    Set addIn = Application.COMAddIns("AlignSQLEndurCSV")
//    Set automationObject = addIn.Object
//    automationObject.ImportData
//End Sub


namespace AlignSQLEndurCSV
{
    public partial class ThisAddIn
    {
        private cVBA VBA;
        protected override object RequestComAddInAutomationService()
        {
            if (VBA == null)
                VBA = new cVBA();
            return VBA;
        }
        protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
        {
            return new Ribbon();
        }
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
