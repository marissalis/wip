﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlignSQLEndurCSV
{
    public partial class frmProfile : Form
    {
        public string resp;
        public frmProfile()
        {
            InitializeComponent();
            this.Text = "Profile data";
            this.CancelButton = button2;
        }

        private void frmProfile_Load(object sender, EventArgs e)
        {
            string[] jurisdiction = { "ni_detail", "roi_detail", "fpa_detail" };
            string[] crtype = { "gas", "fx", "carbon", "ff gas" };
            this.cboxJurisdiction.DataSource = jurisdiction;
            this.cboxCRType.DataSource = crtype;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            resp = null; Application.Exit();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            switch (this.cboxJurisdiction.SelectedValue.ToString() + ", " + this.cboxCRType.SelectedValue.ToString())
            {
                case "ni_detail, gas": resp = "select 'ni_detail' as [tbl], 'gas' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [ni_detail];"; break;
                case "ni_detail, fx": resp = "select 'ni_detail' as [tbl], 'fx' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [ni_detail]WHERE [FX Status]='Floating';"; break;
                case "ni_detail, carbon": resp = "select 'ni_detail' as [tbl], 'carbon' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [ni_detail]WHERE [Carbon Status]='Floating';"; break;
                case "ni_detail, ff gas": resp = "select 'ni_detail' as [tbl], 'ff gas' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [ni_detail]WHERE [FX Status]='Fully Floating';"; break;
                case "roi_detail, gas": resp = "select 'roi_detail' as [tbl], 'gas' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon_Status] as [Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [roi_detail];"; break;
                case "roi_detail, fx": resp = "select 'roi_detail' as [tbl], 'fx' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [roi_detail]WHERE [FX Status]='Floating';"; break;
                case "roi_detail, carbon": resp = "select 'roi_detail' as [tbl], 'carbon' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [roi_detail]WHERE [Carbon_Status]='Floating';"; break;
                case "roi_detail, ff gas": resp = "select 'roi_detail' as [tbl], 'ff gas' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [roi_detail]WHERE [FX Status]='Fully Floating';"; break;
                case "fpa_detail, gas": resp = "select 'fpa_detail' as [tbl], 'gas' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[wd_we] as [Day Type],[total demand] as [Total MWh],[fixed_percent] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [fpa_detail];"; break;
                case "fpa_detail, fx": resp = "select 'fpa_detail' as [tbl], 'fx' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [fpa_detail]WHERE [FX Status]='Floating';"; break;
                case "fpa_detail, carbon": resp = "select 'fpa_detail' as [tbl], 'carbon' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [fpa_detail]WHERE [Carbon Status]='Floating';"; break;
                case "fpa_detail, ff gas": resp = "select 'fpa_detail' as [tbl], 'ff gas' as [cr_type],cstr([MPRN]) as [MPRN],[Gas Index],[Carbon Status],[FX Status],[Heren Charge],[Month] as [Delivery Month],[Day Type],[total demand] as [Total MWh],[fixed pct] as [Position],[GCF],[p01] as [P1],[p02] as [P2],[p03] as [P3],[p04] as [P4],[p05] as [P5],[p06] as [P6],[p07] as [P7],[p08] as [P8],[p09] as [P9],[P10],[P11],[P12],[P13],[P14],[P15],[P16],[P17],[P18],[P19],[P20],[P21],[P22],[P23],[P24],[P25],[P26],[P27],[P28],[P29],[P30],[P31],[P32],[P33],[P34],[P35],[P36],[P37],[P38],[P39],[P40],[P41],[P42],[P43],[P44],[P45],[P46],[P47],[P48] from [fpa_detail]WHERE [FX Status]='Fully Floating';"; break;
                default: resp = ""; break;
            }
            this.Close();
        }
    }
}
