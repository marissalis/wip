﻿namespace AlignSQLEndurCSV
{
    partial class frmProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCRType = new System.Windows.Forms.Label();
            this.lblJurisdiction = new System.Windows.Forms.Label();
            this.cboxCRType = new System.Windows.Forms.ComboBox();
            this.cboxJurisdiction = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCRType
            // 
            this.lblCRType.AutoSize = true;
            this.lblCRType.Location = new System.Drawing.Point(12, 47);
            this.lblCRType.Name = "lblCRType";
            this.lblCRType.Size = new System.Drawing.Size(85, 13);
            this.lblCRType.TabIndex = 7;
            this.lblCRType.Text = "Select CR Type:";
            // 
            // lblJurisdiction
            // 
            this.lblJurisdiction.AutoSize = true;
            this.lblJurisdiction.Location = new System.Drawing.Point(12, 20);
            this.lblJurisdiction.Name = "lblJurisdiction";
            this.lblJurisdiction.Size = new System.Drawing.Size(95, 13);
            this.lblJurisdiction.TabIndex = 6;
            this.lblJurisdiction.Text = "Select Jurisdiction:";
            // 
            // cboxCRType
            // 
            this.cboxCRType.FormattingEnabled = true;
            this.cboxCRType.Location = new System.Drawing.Point(113, 44);
            this.cboxCRType.Name = "cboxCRType";
            this.cboxCRType.Size = new System.Drawing.Size(197, 21);
            this.cboxCRType.TabIndex = 5;
            // 
            // cboxJurisdiction
            // 
            this.cboxJurisdiction.FormattingEnabled = true;
            this.cboxJurisdiction.Location = new System.Drawing.Point(113, 17);
            this.cboxJurisdiction.Name = "cboxJurisdiction";
            this.cboxJurisdiction.Size = new System.Drawing.Size(197, 21);
            this.cboxJurisdiction.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(49, 86);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(227, 44);
            this.button1.TabIndex = 8;
            this.button1.Text = "Load Profile";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(125, 97);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // frmProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 142);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblCRType);
            this.Controls.Add(this.lblJurisdiction);
            this.Controls.Add(this.cboxCRType);
            this.Controls.Add(this.cboxJurisdiction);
            this.Controls.Add(this.button2);
            this.Name = "frmProfile";
            this.Text = "frmProfile";
            this.Load += new System.EventHandler(this.frmProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCRType;
        private System.Windows.Forms.Label lblJurisdiction;
        private System.Windows.Forms.ComboBox cboxCRType;
        private System.Windows.Forms.ComboBox cboxJurisdiction;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}