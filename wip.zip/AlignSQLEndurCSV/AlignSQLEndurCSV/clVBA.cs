﻿using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using Msgbox = System.Windows.Forms.MessageBox;
using System.Windows.Forms;

namespace AlignSQLEndurCSV
{
    [ComVisible(true)]
    public interface IcVBA
    {
        void wip();
        void mvc_rfodb(string str); // to-be procs
    }
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.None)]
    public class cVBA : IcVBA
    {
        public void wip() { }
        public void mvc_rfodb(string str)
        {
            switch (str)
            {
                case "pam1": return; break;
                default: Msgbox.Show("Parameter supplied did not return a process"); break;
            }
        }
        public Excel.Worksheet sh_cnm(Excel.Workbook bk, string cnm)
        {
            for (int i = 0; i < bk.Worksheets.Count; i++)
            {
                if (bk.Worksheets[i + 1].Codename == cnm)
                {
                    return bk.Worksheets[i + 1]; i = bk.Worksheets.Count;
                }
                else { }
            }
            return null;
        }
        public string tbl_csv(DataTable dt, bool b_hdr)
        {
            string[] vh = new string[dt.Columns.Count];
            for (int c = 0; c < dt.Columns.Count; c++) { vh[c] = string.Join(",", dt.Columns[c].ColumnName); }
            string[] vd = new string[dt.Rows.Count];
            for (int r = 0; r < dt.Rows.Count; r++) { vd[r] = string.Join(",", dt.Rows[r].ItemArray); }
            string str = string.Join(",", vh) + "\n" + string.Join("\n", vd); ;
            return str; //return string.Join("\n", vd);
        }
        public string lo_csv(Microsoft.Office.Interop.Excel.ListObject lo, bool b_hdr)
        {
            object[] vr = new object[lo.Range.Rows.Count];
            for (int r = 0; r < lo.Range.Rows.Count; r++)
            {   object[] vc = new object[lo.Range.Columns.Count];
                for (int c = 0; c < lo.Range.Columns.Count; c++)
                { vc[c] = lo.Range.Cells[r + 1, c + 1].Value; }
                vr[r] = string.Join(",", vc);
            } return string.Join("\n", vr);
        }
        public void ExportData(string cn, string sp, string fpath)
        {
            Excel.Workbook bk;
            Excel.Worksheet sh_view; Excel.ListObject lo_view;
            try
            {
                bk = Globals.ThisAddIn.Application.ActiveWorkbook;
                sh_view = sh_cnm(bk, "sh_view"); lo_view = sh_view.ListObjects["t_view"];
            }
            catch { Msgbox.Show("Missing Excel Component!"); return; }

            System.Data.DataTable t1 = sql_tbl(cn, sp, 1);
            System.Data.DataTable t2 = sql_tbl(cn, sp, 2);
            System.Data.DataTable t3 = sql_tbl(cn, sp, 3);

            string csv1 = tbl_csv(t1, true);
            string csv2 = tbl_csv(t2, true);
            string csv3 = tbl_csv(t3, true);
            string[] lines = { csv1, "\n", csv2, "\n", csv3 };

            //string str = lo_csv(lo_view, true); System.IO.File.WriteAllText(fpath, csv3);
            System.IO.File.WriteAllLines(fpath, lines);

        }
        public void tbl_lo(System.Data.DataTable tbl, Excel.ListObject lo)
        {
            try
            {
                Microsoft.Office.Tools.Excel.ListObject lo_obj = AlignSQLEndurCSV.Globals.Factory.GetVstoObject(lo);
                if (lo.ListRows.Count != 0 ) { lo_obj.DataBodyRange.Delete(); }
                try { lo.Range.ClearFormats(); } catch { }
                lo_obj.AutoSetDataBoundColumnHeaders = true;
                lo_obj.SetDataBinding(tbl, null, null);
                lo_obj.Disconnect();
                Excel.Worksheet sh = lo.Parent; sh.Columns.AutoFit();
            }
            catch { Msgbox.Show("Cannot update Excel table!"); return; }
        }
        public void tbl_rng(System.Data.DataTable tbl, Excel.Range rng)
        {
            if (tbl.Rows.Count == 0) { return; }
            //try
            //{
                object[,] v = new object[tbl.Rows.Count, tbl.Columns.Count];
                for (int r = 0; r < tbl.Rows.Count; r++)
                {
                    DataRow dr = tbl.Rows[r];
                    for (int c = 0; c < tbl.Columns.Count; c++)
                    {
                        v[r, c] = dr[c];
                    }
                }
            rng = rng.Resize[tbl.Rows.Count, tbl.Columns.Count];
            rng.Font.Color = 255; rng.Value = v;
            //}
            //catch { Msgbox.Show("Cannot update Excel table!"); return; }
        }
        public void rfodb_tbl_load(string sql_fpath, string sql_cmd, Excel.ListObject lo)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(sql_fpath))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = sql_cmd;
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    var da = new SqlDataAdapter(cmd);
                    var tbl = new DataTable(); da.Fill(tbl);
                    tbl_lo(tbl, lo);
                }
            }
            catch { Msgbox.Show("Error connecting to SQL"); return; }
        }
        public void RfodbDemandView()
        {
            Excel.Workbook bk = Globals.ThisAddIn.Application.ActiveWorkbook;
            Excel.Worksheet sh_profile; Excel.ListObject lo_profile;

            if (System.Environment.UserName.ToLower() != "unm") { Msgbox.Show(""); return; }

            string adb_fpath = @".accdb";
            string sql_fpath = "Data Source=snm;Initial Catalog=catnm;Integrated Security=TRUE;";

            try { sh_profile = bk.Worksheets["profile"]; } catch { sh_profile = bk.Worksheets.Add(After:bk.Worksheets[bk.Worksheets.Count]); sh_profile.Name = "profile"; }
            try { lo_profile = sh_profile.ListObjects["t_profile"]; } catch { lo_profile = sh_profile.ListObjects.AddEx(); lo_profile.Name = "t_profile"; rfodb_tbl_load(sql_fpath, "sp_", lo_profile); lo_profile.DataBodyRange.Delete(); }

            frmProfile frm = new frmProfile(); frm.ShowDialog(); if (frm.resp == null) { return; }
            MODBSQLXLS(adb_fpath, frm.resp, "sp_cr_profile", lo_profile);
            bk.Application.StatusBar = "MOFODB: " + adb_fpath;
            return;
        }
        public bool ValReqData()
        {
            Excel.Workbook bk; Excel.Worksheet sh; Excel.ListObject lo; var sql_tbl = new DataTable(); DataTable tbla; DataTable tblz; bool b;
            try { bk = Globals.ThisAddIn.Application.ActiveWorkbook; } catch { Msgbox.Show("Missing Excel Component!"); return false; }
            try
            {
                sh = sh_cnm(bk, "sh_rfodb_cr");
                lo = sh.ListObjects["t_rfodb_cr"];
            }
            catch
            {
                try { sh = bk.Worksheets["input"]; lo = sh.ListObjects["t_input"]; }
                catch { Msgbox.Show("Missing Excel Component!"); return false; }
            }
            string cnstr = "";
            using (SqlConnection conn = new SqlConnection(cnstr))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = "sp_";
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                var da = new SqlDataAdapter(cmd);
                var tbl = new DataTable(); da.Fill(tbl);

                if (lo.ListRows.Count == 0) { return false; }

                tbla = tbl.Clone(); tblz = tbl.Clone();
                for (int c = 0; c < tblz.Columns.Count; c++) { tblz.Columns[c].DataType = typeof(object); }

                for (int r = 1; r <= lo.ListRows.Count; r++)
                {
                    object[] rw = new object[tbla.Columns.Count];
                    for (int c = 0; c < tbla.Columns.Count; c++) { rw[c] = lo.ListRows[r].Range.Cells[c + 1].Value; }
                    try { tbla.Rows.Add(rw); } catch { tblz.Rows.Add(rw); }
                }
                
                //Globals.ThisAddIn.Application.AutoCorrect.AutoExpandListRange = false;
                tbl_lo(tbla, lo);
                if (tblz.Rows.Count != 0) { tbl_rng(tblz, lo.Parent.Cells[lo.Range.Cells[lo.Range.Cells.Count].Row + 1, lo.Range.Cells[1].Column]); }
                //Globals.ThisAddIn.Application.AutoCorrect.AutoExpandListRange = true;

                b = tblz.Rows.Count == 0 && lo.ListRows.Count != 0;
                conn.Close();
                lo.Parent.Select();
            }
            return b;
        }
        public bool BReqRws()
        {
            Excel.Workbook bk = Globals.ThisAddIn.Application.ActiveWorkbook;
            try
            {
                Msgbox.Show(bk.Worksheets["sh_fx"].ListObjects["t_fx"].ListRows.Count.ToString());
                if (bk.Worksheets["sh_fx"].ListObjects["t_fx"].ListRows.Count
                    * bk.Worksheets["sh_input"].ListObjects["t_input"].ListRows.Count != 0) { return true; }
                else { return false; }
            }
            catch { return false; }
        }
        public void RfodbCustRequest()
        {
            Excel.Workbook bk = Globals.ThisAddIn.Application.ActiveWorkbook;
            Excel.Worksheet sh_input; Excel.ListObject lo_input;
            Excel.Worksheet sh_fx; Excel.ListObject lo_fx;
            bool b_xlobj = false;

            if (System.Environment.UserName.ToLower() != "virrxm") { Msgbox.Show(""); return; }

            string sql_fpath = "Data Source=;Initial Catalog=;Integrated Security=TRUE;";
            try { sh_input = bk.Worksheets["input"]; } catch { sh_input = bk.Worksheets.Add(After: bk.Worksheets[bk.Worksheets.Count]); sh_input.Name = "input"; b_xlobj = true; }
            try { lo_input = sh_input.ListObjects["t_input"]; } catch { lo_input = sh_input.ListObjects.AddEx(); lo_input.Name = "t_input"; rfodb_tbl_load(sql_fpath, "sp_form", lo_input); lo_input.DataBodyRange.Delete(); b_xlobj = true; }
            
            if (b_xlobj) { return; }
            if (ValReqData() == false) { Msgbox.Show("Invalid data entry!"); return; }

            int fx = 0; using (Form ibox = new Form())
            {
                System.Windows.Forms.TextBox tbox = new TextBox();
                Button btnOK = new Button(); btnOK.DialogResult = System.Windows.Forms.DialogResult.OK; btnOK.Size = new System.Drawing.Size(0, 0);
                Button btnCncl = new Button(); btnCncl.DialogResult = System.Windows.Forms.DialogResult.Cancel; btnCncl.Size = new System.Drawing.Size(0, 0);
                ibox.Text = "Enter GBP_EUR Rate";
                ibox.Controls.Add(tbox); ibox.Controls.Add(btnOK); ibox.AcceptButton = btnOK; ibox.CancelButton = btnCncl;
                DialogResult dr = ibox.ShowDialog();
                if (dr != DialogResult.OK) { return; }
                try { fx = System.Int32.Parse(tbox.Text); }
                catch { Msgbox.Show("Enter valid number!"); return; }
            }
            try
            {
                try { lo_fx.DataBodyRange.Delete(); } catch { } lo_fx.ListRows.AddEx();
                lo_fx.ListColumns["fx_date"].DataBodyRange.Cells.Value = string.Format("{0:s}", System.DateTime.UtcNow);
                lo_fx.ListColumns["fx"].DataBodyRange.Cells.Value = "GBP_EUR";
                lo_fx.ListColumns["fx_rate"].DataBodyRange.Cells[1].Value = fx;
            }
            catch { Msgbox.Show("Error inputting FX rate"); return; }

            cr_fx(); cr_input();
            return;
        }
        public void RfodbCustCanc()
        {
            Excel.Workbook bk = Globals.ThisAddIn.Application.ActiveWorkbook;
            Excel.Worksheet sh_canc; Excel.ListObject lo_canc;
            System.Data.DataTable form_lo_tbl; bool b_tbl_tvp;

            //Msgbox.Show("This will enable FO user to cancel an existing request"); return;
            if ( System.Environment.UserName.ToLower() != "virrxm" ) { Msgbox.Show(""); return; }

            string sql_fpath = "Data Source=;Initial Catalog=;Integrated Security=TRUE;";
            try { sh_canc = bk.Worksheets["cancel"]; } catch { sh_canc = bk.Worksheets.Add(); sh_canc.Name = "cancel"; }
            try { lo_canc = sh_canc.ListObjects["t_cancel"]; } catch { lo_canc = sh_canc.ListObjects.AddEx(); lo_canc.Name = "t_cancel"; rfodb_tbl_load(sql_fpath, "sp_cr_canc_form", lo_canc); lo_canc.DataBodyRange.Delete(); return; }

            form_lo_tbl = lo_form_val(lo_canc, "sp_cr_canc_form"); if (form_lo_tbl == null) { return; }
            b_tbl_tvp = tbl_tvp(form_lo_tbl, "sp_cr_canc"); if (b_tbl_tvp != true) { return; }

            bk.Application.DisplayAlerts = false; sh_canc.Delete(); bk.Application.DisplayAlerts = true;
            try { sh_canc = bk.Worksheets["cancel_data"]; } catch { sh_canc = bk.Worksheets.Add(); sh_canc.Name = "cancel_data"; }
            try { lo_canc = sh_canc.ListObjects["t_cancel_data"]; } catch { lo_canc = sh_canc.ListObjects.AddEx(); lo_canc.Name = "t_cancel_data"; }
            form_lo_tbl = cmd_tbl(lo_canc, "sp_cr_canc_data"); tbl_lo(form_lo_tbl, lo_canc);

            return;
        }
        public void RfodbDemandUpdate()
        {
            Msgbox.Show("This will enable MO user to update Profile data"); return;
            if (System.Environment.UserName.ToLower() != "virrxm") { Msgbox.Show("This will enable MO user to update Profile data"); return; }
        }
        public bool tbl_tvp(System.Data.DataTable tbl, string spnm)
        {
            if (tbl.Rows.Count == 0) { return false; }
            try
            {
                string cnstr = "Data Source=;Initial Catalog=;Integrated Security=TRUE;";
                using (SqlConnection conn = new SqlConnection(cnstr))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = spnm;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@tvp", tbl);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                return true;
            }
            catch { Msgbox.Show("Unable to send form data to SQL in bulk request"); return false; }
        }
        public System.Data.DataTable cmd_tbl(Excel.ListObject lo, string spnm)
        {
            System.Data.DataTable tbl = new DataTable();
            string cnstr = "Data Source=;Initial Catalog=;Integrated Security=TRUE;";
            try
            {
                using (SqlConnection conn = new SqlConnection(cnstr))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = spnm; cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    var da = new SqlDataAdapter(cmd);
                    da.Fill(tbl);
                }
            }
            catch { return null; }
            return tbl;
        }
        public System.Data.DataTable lo_form_val(Excel.ListObject lo, string spnm)
        {
            System.Data.DataTable tvp = new DataTable(); System.Data.DataTable tbla; System.Data.DataTable tblz;
            if (lo.ListRows.Count == 0) { return null; }

            string cnstr = "Data Source=;Initial Catalog=;Integrated Security=TRUE;";
            try
            {
                using (SqlConnection conn = new SqlConnection(cnstr))
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = spnm; cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    var da = new SqlDataAdapter(cmd); da.Fill(tvp);
                    //Msgbox.Show(tbl.Constraints.Count.ToString());
                    tbla = tvp.Clone(); tblz = tvp.Clone();
                    for (int c = 0; c < tblz.Columns.Count; c++) { tblz.Columns[c].DataType = typeof(object); }

                    for (int r = 1; r <= lo.ListRows.Count; r++)
                    {
                        object[] rw = new object[tbla.Columns.Count];
                        for (int c = 0; c < tbla.Columns.Count; c++) { rw[c] = lo.ListRows[r].Range.Cells[c + 1].Value; }
                        try { tbla.Rows.Add(rw); } catch { tblz.Rows.Add(rw); }
                    }

                    tbl_lo(tbla, lo);
                    if (tblz.Rows.Count != 0) { tbl_rng(tblz, lo.Parent.Cells[lo.Range.Cells[lo.Range.Cells.Count].Row + 1, lo.Range.Cells[1].Column]); return null; }

                    conn.Close();
                    return tbla;
                }

            }
            catch { Msgbox.Show("Unable to connect SQL and validate entry"); return null; }
        }
    }
}
