﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using System.Net;
using System.Data.SqlClient;

namespace TrayForm
{
    public partial class Form1 : Form
    {
        bool mLoaded;
        string sw_nfy;
        private static System.Timers.Timer aTimer;
        protected override void SetVisibleCore(bool value)
        {
            if (value && !mLoaded)
            {
                this.CreateHandle();   // Ensure the Load event runs
                value = false;         // Keep invisible
                mLoaded = true;
            }
            base.SetVisibleCore(value);
        }
        public Form1()
        {
            InitializeComponent();
            sw_nfy = fstr_max();
            SetBalloonTip();
            SetTimer();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.MessageBox.Show("Set Timer change icon");
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
            Hide();
            SetTimer();
        }
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //System.Windows.Forms.MessageBox.Show("TBD dev yesno");
            Show(); WindowState = FormWindowState.Normal;
        }
        private void Form1_Click(object sender, EventArgs e)
        {
            notifyIcon1.Visible = true;
            notifyIcon1.ShowBalloonTip(30000);
        }
        private void SetTimer()
        {
            aTimer = new System.Timers.Timer(30000);
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            if ( fstr_max() != sw_nfy )
            { sw_timedevent(); sw_nfy = fstr_max(); }
            else {  }
        }
        private void sw_timedevent()
        {
            //SetBalloonTip();
            notifyIcon1.Visible = true;
            //notifyIcon1.Icon = SystemIcons.Exclamation;
            notifyIcon1.ShowBalloonTip(30000);
            aTimer.Stop(); aTimer.Dispose();
        }
        private void SetBalloonTip()
        {
            //aTimer.Stop(); aTimer.Dispose();
            //notifyIcon1.Icon = SystemIcons.Exclamation;
            //notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            notifyIcon1.BalloonTipTitle = "Balloon Tip Title";
            notifyIcon1.BalloonTipText = "Balloon Tip Text.";
            //notifyIcon1.BalloonTipText = fstr_max();
            notifyIcon1.BalloonTipIcon = ToolTipIcon.Error;
            //this.Click += new EventHandler(Form1_Click);
        }
        public static string fstr_max()
        {
            string str;
            using (SqlConnection conn = new SqlConnection("Data Source=;Initial Catalog=;Integrated Security=SSPI;"))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = "";
                cmd.CommandType = CommandType.Text;
                conn.Open();
                str = "test" + (int)cmd.ExecuteScalar();
                conn.Close();
            }
            return str;

            //string url = @"url";
            //WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultCredentials;
            //IWebProxy pobj = WebRequest.DefaultWebProxy;
            //WebRequest req = WebRequest.Create(url);
            //WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultCredentials;
            //WebResponse response = (WebResponse)req.GetResponse();
            //Stream dataStream = response.GetResponseStream();
            //StreamReader reader = new StreamReader(dataStream);
            //string responseFromServer = reader.ReadToEnd();
            //return responseFromServer;

            //reader.Close();
            //dataStream.Close();
            //response.Close();
        }
    }
}
